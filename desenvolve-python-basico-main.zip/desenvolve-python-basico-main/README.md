# desenvolve-python-basico
Cidade onde o curso está sendo realizado: Itabira
Nome da disciplina Programação básica com PYTHON
Matrícula: PDITA465
