#Leitura de dados
fahrenheit=int(input("digite a temperatura em fahrenheit:"))

#Processamento
celsius= (fahrenheit-32)*5/9

#impressao
print(f"{fahrenheit} graus Fahrenheit são {int(celsius)} graus Celsius.")
