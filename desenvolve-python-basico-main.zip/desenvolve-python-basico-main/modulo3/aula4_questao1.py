n1,n2= int(input()), int(input())
if ((n1+n2) % 2)==0:
    print("é par!")
else:
    print("é impar!")