#entrada
#idade j
#idade c
idadej=int(input())
idadec=int(input())

#processamento e saida
pode_entrar= idadej >= 18 or idadec >= 18
print(pode_entrar)