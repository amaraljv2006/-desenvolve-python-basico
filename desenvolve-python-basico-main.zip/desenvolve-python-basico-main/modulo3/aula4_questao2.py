avaliação_dos_usuarios=int(input("insira uma avaliação de um filme em uma escala de 1 a 5:"))
if (avaliação_dos_usuarios)== 5:
    print("Excelente!")
if (avaliação_dos_usuarios)== 4:
    print("Muito bom!")
if (avaliação_dos_usuarios)== 3:
    print("Bom!")
if (avaliação_dos_usuarios)== 2:
    print("Regular!")
if (avaliação_dos_usuarios)== 1:
    print("Ruim!")