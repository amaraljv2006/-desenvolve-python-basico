n=int(input())
cont=0
while n<cont:
    print (cont)
    cont+=1
      
print("fim!")