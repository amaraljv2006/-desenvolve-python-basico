x=int(input())
n=5
while x>n:
    
    print (f"{x} é maior que 5!")

if x<n:
    print(f"{x} não é maior que 5!")

print("fim!")

